from tkinter import *
import random

class SieteGanador:
    def __init__(self):
        self.crear_interfaz()
        self.contador_sietes = 0  # Inicializa el contador de sietes

    def crear_interfaz(self):
        ventana = Tk()
        ventana.minsize(340, 450)
        ventana.geometry('340x450')
        boton = Button(ventana, text='jugar!!', command=self.jugar, font='arial 18 bold')
        boton.pack()
        foto = PhotoImage(file='Ganar.png')
        self.gano = Label(ventana, image=foto)

        self.campo = [StringVar() for elemento in range(3)]
        posicion = 10
        for campo in self.campo:
            label = Label(ventana, textvariable=campo, background='White', foreground='Black', font='arial 42 bold')
            label.place(x=posicion, y=100, width=100, height=100)
            posicion += 110
        self.leyenda = Label(ventana, text='', font='arial 18 bold')
        self.leyenda.pack()
        ventana.mainloop()

    def generar_numero(self):
        return random.randint(0, 9)

    def jugar(self):
	
        for i in range(3):
            valor = self.generar_numero()
            self.campo[i].set(valor)

            if valor == 7:
                siete_aparecido = True
                self.gano.pack(side=BOTTOM)  # Muestra la imagen si se obtiene un 7
            else:
                self.gano.pack_forget()  # Oculta la imagen si no es un 7


            if valor == 7:
                self.contador_sietes += 1  # Incrementa el contador de sietes

        if self.contador_sietes == 3:
            self.leyenda.config(text='FELICIDADES ACABAS DE GANAR LA FORTUNA MAYOR')
        else:
            self.leyenda.config(text='')  # Borra la leyenda si no se ganó

jugar = SieteGanador()