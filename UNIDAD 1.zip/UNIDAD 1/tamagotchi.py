import random
import time

class Tamagotchi:
    def __init__(self, nombre):
        self.nombre = nombre
        self.hambre = 50
        self.energia = 50
        self.felicidad = 50
        self.salud = 100

    def mostrar_estado(self):
        print(f"{self.nombre}:")
        print(f"Hambre: {self.hambre}/100")
        print(f"Energía: {self.energia}/100")
        print(f"Felicidad: {self.felicidad}/100")
        print(f"Salud: {self.salud}/100")

    def alimentar(self):
        self.hambre += random.randint(5, 15)
        if self.hambre > 100:
            self.hambre = 100
        self.energia -= 5
        self.felicidad += 5

    def jugar(self):
        self.hambre -= 5
        self.energia -= random.randint(10, 20)
        self.felicidad += random.randint(10, 20)

    def dormir(self):
        self.hambre -= 5
        self.energia += random.randint(15, 30)
        self.felicidad -= 10

    def cuidar_salud(self):
        self.salud += random.randint(5, 10)
        self.felicidad -= 5

    def envejecer(self):
        self.salud -= random.randint(1, 5)

    def vivir_un_dia(self):
        self.hambre -= random.randint(5, 10)
        self.energia -= random.randint(5, 15)
        self.felicidad -= random.randint(1, 5)
        self.envejecer()

    def esta_vivo(self):
        return self.hambre > 0 and self.salud > 0

def main():
    nombre = input("Elige un nombre para tu Tamagotchi: ")
    tamagotchi = Tamagotchi(nombre)

    while tamagotchi.esta_vivo():
        tamagotchi.mostrar_estado()
        accion = input("¿Qué quieres hacer? (alimentar/jugar/dormir/cuidar salud/salir): ")

        if accion == "alimentar":
            tamagotchi.alimentar()
        elif accion == "jugar":
            tamagotchi.jugar()
        elif accion == "dormir":
            tamagotchi.dormir()
        elif accion == "cuidar salud":
            tamagotchi.cuidar_salud()
        elif accion == "salir":
            print("¡Adiós!")
            break
        else:
            print("Acción no válida. Inténtalo de nuevo.")

        tamagotchi.vivir_un_dia()

if __name__ == "__main__":
    main()
